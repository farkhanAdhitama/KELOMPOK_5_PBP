package id.ifundip.servicedemo;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

import androidx.annotation.Nullable;

public class SoundService extends Service {
    MediaPlayer player;
    String nama_lagu;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nama_lagu = intent.getStringExtra("full_name");
        if(player == null){
            if(player == null && nama_lagu == "1") {
                player = MediaPlayer.create(this, R.raw.vokal);
            }
            else if(nama_lagu == "1") {
                player = MediaPlayer.create(this, R.raw.piano1stanza);
            }
            else if(nama_lagu == "2") {
                player = MediaPlayer.create(this, R.raw.piano3stanza);
            }
        }
        player.start();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopPlayer();
    }

    private void stopPlayer(){
        if(player != null){
            player.release();
            player = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
