package id.ifundip.servicedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Arrays;

import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    MediaPlayer player;
    Spinner listLagu;
    Button playButton, stopButton;
    int positionDataSpinner;

     String[] daftar_lagu = {"Pilih lagu","Indonesia Raya vokal", "Indonesia Raya Piano 1 Stanza"
     ,"Indonesia Raya Piano 3 Stanza"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listLagu = findViewById(R.id.listLagu);
        ArrayAdapter<CharSequence> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, daftar_lagu);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listLagu.setAdapter(adapter);
        listLagu.setOnItemSelectedListener(this);
        String selection = "Pilih Lagu";
        int spinnerPosition = adapter.getPosition(selection);
        listLagu.setSelection(spinnerPosition);

    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(MainActivity.this,""+daftar_lagu[position]+"Selected..",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
    public void playButtonHandler(View view){
        startService(new Intent(this, SoundService.class));
    }

    public void stopButtonHandler(View view){
        stopService(new Intent(this, SoundService.class));
    }

}